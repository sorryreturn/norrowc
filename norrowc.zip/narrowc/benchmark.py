"""
benchmark.py

Compiles bench.py with ast_walker and times the resulting native binary
against plain CPython running the same source, on a compute-bound loop
with no I/O in the hot path (I/O overhead would dominate and hide the
actual loop/arithmetic speed difference).

usage:
    ./ast_walker --check bench.py     # confirm it lands in the native subset first
    python3 benchmark.py
"""

import subprocess
import time

SOURCE = "bench.py"
BINARY = "./bench"


def time_run(cmd):
    t0 = time.perf_counter()
    subprocess.run(cmd, stdout=subprocess.DEVNULL, check=True)
    return time.perf_counter() - t0


if __name__ == "__main__":
    c_time = time_run([BINARY])
    py_time = time_run(["python3", SOURCE])

    print(f"native C:  {c_time:.4f}s")
    print(f"python:    {py_time:.4f}s")
    print(f"speedup:   {py_time / c_time:.1f}x")