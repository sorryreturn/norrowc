i = 0
total = 0
while i < 1000000000:
    total = total + i
    i = i + 1
print(total)