/*
 * ast_walker.c
 *
 * Validate a small Python subset and generate equivalent C.  The validator
 * uses Python's ast module through the CPython embedding API so it follows
 * the host interpreter's grammar instead of reimplementing Python parsing.
 *
 * to build:
 *   gcc -std=c11 -Wall -Wextra -O2 ast_walker.c -o ast_walker \
 *       $(python3-config --embed --cflags --ldflags) -lm
 *
 * to use:
 *   ./ast_walker input.py output.c
 *   ./ast_walker --check input.py
 */

#define PY_SSIZE_T_CLEAN
#include <Python.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum { TYPE_INT, TYPE_DOUBLE } CType;

typedef struct {
	FILE *out;
	int indent;
	int supported;
	const char *reason;
	char **declared;
	CType *declared_type;
	size_t declared_count;
} Walker;

static void fail(Walker *walker, const char *reason) {
	if (walker->supported) {
		walker->supported = 0;
		walker->reason = reason;
	}
}

static void emit_c_string(FILE *out, const char *source) {
	fputc('"', out);
	for (const unsigned char *cursor = (const unsigned char *)source; *cursor; ++cursor) {
		if (*cursor == '\\') fputs("\\\\", out);
		else if (*cursor == '"') fputs("\\\"", out);
		else if (*cursor == '\n') fputs("\\n", out);
		else if (*cursor == '\r') fputs("\\r", out);
		else if (*cursor == '\t') fputs("\\t", out);
		else fprintf(out, "%c", *cursor);
	}
	fputc('"', out);
}

static void emit_python_fallback(FILE *out, const char *source) {
	fputs("#include <Python.h>\n\n", out);
	fputs("int main(void) {\n", out);
	fputs("    Py_Initialize();\n", out);
	fputs("    if (PyRun_SimpleString(\n", out);
	fputs("        ", out);
	emit_c_string(out, source);
	fputs(") != 0) { PyErr_Print(); Py_Finalize(); return 1; }\n", out);
	fputs("    Py_Finalize();\n    return 0;\n}\n", out);
}

static int is_name(PyObject *node, const char *name) {
	PyObject *id = PyObject_GetAttrString(node, "id");
	int result = id && PyUnicode_Check(id) && strcmp(PyUnicode_AsUTF8(id), name) == 0;
	Py_XDECREF(id);
	return result;
}

static PyObject *field(PyObject *node, const char *name) {
	return PyObject_GetAttrString(node, name);
}

static int type_is(PyObject *node, const char *name) {
	PyObject *type = PyObject_Type(node);
	PyObject *type_name = type ? PyObject_GetAttrString(type, "__name__") : NULL;
	int result = type_name && PyUnicode_Check(type_name) &&
				 strcmp(PyUnicode_AsUTF8(type_name), name) == 0;
	Py_XDECREF(type_name);
	Py_XDECREF(type);
	return result;
}

/* ---------------------------------------------------------------------
 * Validator: decides whether a function/module body is in the supported
 * native subset. Unchanged in spirit from the first draft; still the
 * source of truth for what generate_native() is allowed to assume holds.
 * ------------------------------------------------------------------- */

static int supported_expr(PyObject *node, Walker *walker);
static int supported_stmt(PyObject *node, Walker *walker);

static int supported_expr(PyObject *node, Walker *walker) {
	if (!node || !walker->supported) return 0;
	if (type_is(node, "Constant")) {
		PyObject *value = field(node, "value");
		int ok = value && (PyLong_Check(value) || PyFloat_Check(value) ||
						   PyBool_Check(value));
		Py_XDECREF(value);
		if (!ok) fail(walker, "only int, float, bool, and numeric literals are supported");
		return ok;
	}
	if (type_is(node, "Name")) return 1;
	if (type_is(node, "BinOp")) {
		PyObject *left = field(node, "left"), *right = field(node, "right"), *op = field(node, "op");
		int ok = supported_expr(left, walker) && supported_expr(right, walker);
		if (op && !(type_is(op, "Add") || type_is(op, "Sub") || type_is(op, "Mult") ||
					type_is(op, "Div") || type_is(op, "FloorDiv") || type_is(op, "Mod"))) {
			fail(walker, "unsupported arithmetic operator"); ok = 0;
		}
		Py_XDECREF(left); Py_XDECREF(right); Py_XDECREF(op); return ok;
	}
	if (type_is(node, "UnaryOp")) {
		PyObject *operand = field(node, "operand"), *op = field(node, "op");
		int ok = supported_expr(operand, walker);
		if (op && !(type_is(op, "USub") || type_is(op, "UAdd") || type_is(op, "Not"))) {
			fail(walker, "unsupported unary operator"); ok = 0;
		}
		Py_XDECREF(operand); Py_XDECREF(op); return ok;
	}
	if (type_is(node, "BoolOp")) {
		PyObject *values = field(node, "values");
		int ok = values && PyList_Check(values);
		if (ok) for (Py_ssize_t i = 0; i < PyList_Size(values); ++i)
			ok = supported_expr(PyList_GetItem(values, i), walker) && ok;
		Py_XDECREF(values); return ok;
	}
	if (type_is(node, "Compare")) {
		PyObject *left = field(node, "left"), *comparators = field(node, "comparators"), *ops = field(node, "ops");
		int ok = supported_expr(left, walker);
		if (comparators && ops) {
			for (Py_ssize_t i = 0; i < PyList_Size(comparators); ++i) {
				PyObject *op = PyList_GetItem(ops, i);
				if (!(type_is(op, "Eq") || type_is(op, "NotEq") || type_is(op, "Lt") ||
					  type_is(op, "LtE") || type_is(op, "Gt") || type_is(op, "GtE"))) {
					fail(walker, "unsupported comparison operator"); ok = 0;
				}
				ok = supported_expr(PyList_GetItem(comparators, i), walker) && ok;
			}
		}
		Py_XDECREF(left); Py_XDECREF(comparators); Py_XDECREF(ops); return ok;
	}
	if (type_is(node, "Call")) {
		PyObject *func = field(node, "func"), *args = field(node, "args"), *keywords = field(node, "keywords");
		int ok = func && type_is(func, "Name") && is_name(func, "print") &&
				 args && keywords && PyList_Size(keywords) == 0;
		if (!ok) fail(walker, "only print(...) calls are supported in native C");
		if (args) for (Py_ssize_t i = 0; i < PyList_Size(args); ++i)
			ok = supported_expr(PyList_GetItem(args, i), walker) && ok;
		Py_XDECREF(func); Py_XDECREF(args); Py_XDECREF(keywords); return ok;
	}
	fail(walker, "unsupported expression");
	return 0;
}

static int supported_stmt(PyObject *node, Walker *walker) {
	if (!node || !walker->supported) return 0;
	if (type_is(node, "Expr")) {
		PyObject *value = field(node, "value"); int ok = supported_expr(value, walker);
		Py_XDECREF(value); return ok;
	}
	if (type_is(node, "Assign") || type_is(node, "AnnAssign")) {
		PyObject *value = field(node, "value"); PyObject *targets = field(node, "targets");
		int ok = value && supported_expr(value, walker);
		if (type_is(node, "Assign")) {
			if (!targets || !PyList_Check(targets) || PyList_Size(targets) != 1 ||
				!type_is(PyList_GetItem(targets, 0), "Name")) {
				fail(walker, "assignments must target one simple variable"); ok = 0;
			}
		} else {
			PyObject *target = field(node, "target");
			if (!target || !type_is(target, "Name")) { fail(walker, "annotations must target a simple variable"); ok = 0; }
			Py_XDECREF(target);
		}
		Py_XDECREF(value); Py_XDECREF(targets); return ok;
	}
	if (type_is(node, "Return")) {
		fail(walker, "function returns are reserved for the fallback path until native function emission is implemented");
		return 0;
	}
	if (type_is(node, "If") || type_is(node, "While")) {
		PyObject *test = field(node, "test"), *body = field(node, "body"), *orelse = field(node, "orelse");
		int ok = supported_expr(test, walker);
		if (body) for (Py_ssize_t i = 0; i < PyList_Size(body); ++i) ok = supported_stmt(PyList_GetItem(body, i), walker) && ok;
		if (orelse) for (Py_ssize_t i = 0; i < PyList_Size(orelse); ++i) ok = supported_stmt(PyList_GetItem(orelse, i), walker) && ok;
		Py_XDECREF(test); Py_XDECREF(body); Py_XDECREF(orelse); return ok;
	}
	if (type_is(node, "FunctionDef")) {
		fail(walker, "native function emission is not implemented yet");
		return 0;
	}
	fail(walker, "unsupported statement (native subset supports assignments, expressions, control flow, and functions)");
	return 0;
}

static char *node_text(PyObject *node) {
	PyObject *ast = PyImport_ImportModule("ast");
	PyObject *unparse = ast ? PyObject_GetAttrString(ast, "unparse") : NULL;
	PyObject *text = unparse ? PyObject_CallOneArg(unparse, node) : NULL;
	const char *utf8 = text ? PyUnicode_AsUTF8(text) : NULL;
	char *copy = utf8 ? strdup(utf8) : NULL;
	Py_XDECREF(text); Py_XDECREF(unparse); Py_XDECREF(ast); return copy;
}

/* ---------------------------------------------------------------------
 * Symbol table: name -> inferred C type. Types only ever widen
 * (int -> double), never narrow, so declaration order doesn't matter.
 * ------------------------------------------------------------------- */

static int find_declared(Walker *walker, const char *name) {
	for (size_t i = 0; i < walker->declared_count; ++i)
		if (strcmp(walker->declared[i], name) == 0) return (int)i;
	return -1;
}

static void remember_declaration(Walker *walker, const char *name, CType type) {
	int idx = find_declared(walker, name);
	if (idx >= 0) {
		if (type == TYPE_DOUBLE) walker->declared_type[idx] = TYPE_DOUBLE;
		return;
	}
	char **names = realloc(walker->declared, (walker->declared_count + 1) * sizeof(*names));
	CType *types = realloc(walker->declared_type, (walker->declared_count + 1) * sizeof(*types));
	if (!names || !types) return;
	walker->declared = names;
	walker->declared_type = types;
	walker->declared[walker->declared_count] = strdup(name);
	walker->declared_type[walker->declared_count] = type;
	walker->declared_count++;
}

/* Constants/BinOp/UnaryOp determine type from their operands; Compare and
 * BoolOp results are boolean-ish and treated as int. True division (Div)
 * always widens to double, matching Python's "/" semantics. */
static CType expr_type(PyObject *node, Walker *walker) {
	if (type_is(node, "Constant")) {
		PyObject *value = field(node, "value");
		CType t = (value && PyFloat_Check(value)) ? TYPE_DOUBLE : TYPE_INT;
		Py_XDECREF(value);
		return t;
	}
	if (type_is(node, "Name")) {
		char *name = node_text(node);
		int idx = name ? find_declared(walker, name) : -1;
		free(name);
		return idx >= 0 ? walker->declared_type[idx] : TYPE_INT;
	}
	if (type_is(node, "UnaryOp")) {
		PyObject *op = field(node, "op"), *operand = field(node, "operand");
		CType t = type_is(op, "Not") ? TYPE_INT : expr_type(operand, walker);
		Py_XDECREF(op); Py_XDECREF(operand);
		return t;
	}
	if (type_is(node, "BinOp")) {
		PyObject *left = field(node, "left"), *right = field(node, "right"), *op = field(node, "op");
		CType t;
		if (type_is(op, "Div")) {
			t = TYPE_DOUBLE; /* true division always widens, per Python */
		} else {
			t = (expr_type(left, walker) == TYPE_DOUBLE || expr_type(right, walker) == TYPE_DOUBLE)
				? TYPE_DOUBLE : TYPE_INT;
		}
		Py_XDECREF(left); Py_XDECREF(right); Py_XDECREF(op);
		return t;
	}
	return TYPE_INT; /* Compare / BoolOp */
}

/* Pre-pass: walks the whole body (including into if/while so nested
 * assignments are seen) and builds the symbol table BEFORE any codegen
 * runs, so declarations can be hoisted to the top of main() instead of
 * being written wherever the first assignment happens to land. */
static void infer_block(PyObject *statements, Walker *walker) {
	for (Py_ssize_t i = 0; statements && i < PyList_Size(statements); ++i) {
		PyObject *stmt = PyList_GetItem(statements, i);
		if (type_is(stmt, "Assign") || type_is(stmt, "AnnAssign")) {
			PyObject *value = field(stmt, "value");
			PyObject *targets = type_is(stmt, "Assign") ? field(stmt, "targets") : NULL;
			PyObject *target = targets ? PyList_GetItem(targets, 0) : field(stmt, "target");
			char *name = target ? node_text(target) : NULL;
			if (name) remember_declaration(walker, name, value ? expr_type(value, walker) : TYPE_INT);
			free(name);
			Py_XDECREF(targets);
			if (!targets) Py_XDECREF(target);
			Py_XDECREF(value);
		} else if (type_is(stmt, "If") || type_is(stmt, "While")) {
			PyObject *body = field(stmt, "body"), *orelse = field(stmt, "orelse");
			infer_block(body, walker);
			infer_block(orelse, walker);
			Py_XDECREF(body); Py_XDECREF(orelse);
		}
	}
}

/* ---------------------------------------------------------------------
 * Codegen: writes C token-by-token straight from the AST. Replaces the
 * old text-unparse-then-string-patch approach, which broke on cases like
 * "not" at the start of an expression (no leading space to match on) and
 * risked corrupting identifiers that merely contained "True"/"False".
 * ------------------------------------------------------------------- */

/* Python's // and % floor toward negative infinity; C's / and % truncate
 * toward zero. These only disagree when signs differ, but silently
 * disagreeing is worse than always paying for the correction, so every
 * FloorDiv/Mod goes through one of these instead of raw C operators. */
static const char *RUNTIME_HELPERS =
	"#include <math.h>\n\n"
	"static long long cpy_floordiv_ll(long long a, long long b) {\n"
	"    long long q = a / b, r = a % b;\n"
	"    if (r != 0 && ((r < 0) != (b < 0))) q--;\n"
	"    return q;\n"
	"}\n"
	"static double cpy_floordiv_d(double a, double b) {\n"
	"    return floor(a / b);\n"
	"}\n"
	"static long long cpy_mod_ll(long long a, long long b) {\n"
	"    long long r = a % b;\n"
	"    if (r != 0 && ((r < 0) != (b < 0))) r += b;\n"
	"    return r;\n"
	"}\n"
	"static double cpy_mod_d(double a, double b) {\n"
	"    double r = fmod(a, b);\n"
	"    if (r != 0 && ((r < 0) != (b < 0))) r += b;\n"
	"    return r;\n"
	"}\n\n";

static void emit_c_expr(FILE *out, PyObject *node, Walker *walker) {
	if (type_is(node, "Constant")) {
		PyObject *value = field(node, "value");
		if (PyBool_Check(value)) fputs(PyObject_IsTrue(value) ? "1" : "0", out);
		else if (PyFloat_Check(value)) fprintf(out, "%g", PyFloat_AsDouble(value));
		else fprintf(out, "%lldLL", (long long)PyLong_AsLongLong(value));
		Py_XDECREF(value);
		return;
	}
	if (type_is(node, "Name")) {
		char *name = node_text(node);
		fputs(name ? name : "", out);
		free(name);
		return;
	}
	if (type_is(node, "BinOp")) {
		PyObject *left = field(node, "left"), *right = field(node, "right"), *op = field(node, "op");
		CType result_type = (expr_type(left, walker) == TYPE_DOUBLE || expr_type(right, walker) == TYPE_DOUBLE)
			? TYPE_DOUBLE : TYPE_INT;
		if (type_is(op, "Div")) {
			/* True division always yields double in Python, even for two
			 * ints, so both operands are force-cast regardless of their
			 * own declared type. */
			fputs("((double)(", out); emit_c_expr(out, left, walker);
			fputs(") / (double)(", out); emit_c_expr(out, right, walker);
			fputs("))", out);
		} else if (type_is(op, "FloorDiv") || type_is(op, "Mod")) {
			const char *helper = type_is(op, "FloorDiv")
				? (result_type == TYPE_DOUBLE ? "cpy_floordiv_d" : "cpy_floordiv_ll")
				: (result_type == TYPE_DOUBLE ? "cpy_mod_d" : "cpy_mod_ll");
			fprintf(out, "%s(", helper); emit_c_expr(out, left, walker);
			fputs(", ", out); emit_c_expr(out, right, walker); fputs(")", out);
		} else {
			const char *sym = type_is(op, "Add") ? "+" : type_is(op, "Sub") ? "-" : "*";
			fputc('(', out); emit_c_expr(out, left, walker);
			fprintf(out, " %s ", sym); emit_c_expr(out, right, walker); fputc(')', out);
		}
		Py_XDECREF(left); Py_XDECREF(right); Py_XDECREF(op);
		return;
	}
	if (type_is(node, "UnaryOp")) {
		PyObject *op = field(node, "op"), *operand = field(node, "operand");
		fputs(type_is(op, "USub") ? "-" : type_is(op, "Not") ? "!" : "+", out);
		fputc('(', out); emit_c_expr(out, operand, walker); fputc(')', out);
		Py_XDECREF(op); Py_XDECREF(operand);
		return;
	}
	if (type_is(node, "BoolOp")) {
		PyObject *values = field(node, "values"), *op = field(node, "op");
		const char *sym = type_is(op, "And") ? "&&" : "||";
		fputc('(', out);
		for (Py_ssize_t i = 0; i < PyList_Size(values); ++i) {
			if (i) fprintf(out, " %s ", sym);
			emit_c_expr(out, PyList_GetItem(values, i), walker);
		}
		fputc(')', out);
		Py_XDECREF(values); Py_XDECREF(op);
		return;
	}
	if (type_is(node, "Compare")) {
		PyObject *left = field(node, "left"), *ops = field(node, "ops"), *cmps = field(node, "comparators");
		fputc('(', out); emit_c_expr(out, left, walker);
		for (Py_ssize_t i = 0; i < PyList_Size(ops); ++i) {
			PyObject *op = PyList_GetItem(ops, i);
			const char *sym = type_is(op, "Eq") ? "==" : type_is(op, "NotEq") ? "!=" :
				type_is(op, "Lt") ? "<" : type_is(op, "LtE") ? "<=" : type_is(op, "Gt") ? ">" : ">=";
			fprintf(out, " %s ", sym); emit_c_expr(out, PyList_GetItem(cmps, i), walker);
		}
		fputc(')', out);
		Py_XDECREF(left); Py_XDECREF(ops); Py_XDECREF(cmps);
		return;
	}
	/* Unreachable for a validated node, but never emit silently-wrong C. */
	fputs("0 /* unsupported expr reached codegen */", out);
}

static void emit_native_stmt(PyObject *statement, Walker *walker);

static void emit_native_block(PyObject *statements, Walker *walker) {
	for (Py_ssize_t i = 0; statements && i < PyList_Size(statements); ++i)
		emit_native_stmt(PyList_GetItem(statements, i), walker);
}

static void emit_native_stmt(PyObject *statement, Walker *walker) {
	if (type_is(statement, "Assign") || type_is(statement, "AnnAssign")) {
		PyObject *targets = NULL, *target = NULL, *value = field(statement, "value");
		if (type_is(statement, "Assign")) {
			targets = field(statement, "targets");
			target = targets ? PyList_GetItem(targets, 0) : NULL;
		} else {
			target = field(statement, "target");
		}
		char *name = target ? node_text(target) : NULL;
		if (name) {
			fprintf(walker->out, "    %s = ", name); /* declared up front by generate_native() */
			emit_c_expr(walker->out, value, walker);
			fputs(";\n", walker->out);
		}
		free(name);
		Py_XDECREF(targets);
		if (!targets) Py_XDECREF(target);
		Py_XDECREF(value);
		return;
	}
	if (type_is(statement, "Expr")) {
		PyObject *value = field(statement, "value");
		if (value && type_is(value, "Call")) {
			PyObject *args = field(value, "args");
			Py_ssize_t n = args ? PyList_Size(args) : 0;
			fputs("    printf(\"", walker->out);
			for (Py_ssize_t i = 0; i < n; ++i) {
				CType t = expr_type(PyList_GetItem(args, i), walker);
				fputs(i ? " " : "", walker->out);
				fputs(t == TYPE_DOUBLE ? "%g" : "%lld", walker->out);
			}
			fputs("\\n\"", walker->out);
			for (Py_ssize_t i = 0; i < n; ++i) {
				PyObject *arg = PyList_GetItem(args, i);
				CType t = expr_type(arg, walker);
				fprintf(walker->out, ", (%s)(", t == TYPE_DOUBLE ? "double" : "long long");
				emit_c_expr(walker->out, arg, walker);
				fputs(")", walker->out);
			}
			fputs(");\n", walker->out);
			Py_XDECREF(args);
		}
		Py_XDECREF(value);
		return;
	}
	if (type_is(statement, "If") || type_is(statement, "While")) {
		PyObject *test = field(statement, "test"), *body = field(statement, "body"), *orelse = field(statement, "orelse");
		fprintf(walker->out, "    %s (", type_is(statement, "If") ? "if" : "while");
		emit_c_expr(walker->out, test, walker);
		fputs(") {\n", walker->out);
		emit_native_block(body, walker);
		fputs("    }", walker->out);
		if (orelse && PyList_Size(orelse) > 0 && type_is(statement, "If")) {
			fputs(" else {\n", walker->out);
			emit_native_block(orelse, walker);
			fputs("    }", walker->out);
		}
		fputc('\n', walker->out);
		Py_XDECREF(test); Py_XDECREF(body); Py_XDECREF(orelse);
		return;
	}
	/* Function definitions and returns are validated for fallback only. */
}

static void generate_native(PyObject *module, FILE *out) {
	Walker walker = {out, 0, 1, NULL, NULL, NULL, 0};
	PyObject *body = field(module, "body");

	infer_block(body, &walker); /* build the whole symbol table first */

	fputs(RUNTIME_HELPERS, out);
	fputs("#include <stdio.h>\n\nint main(void) {\n", out);
	for (size_t i = 0; i < walker.declared_count; ++i)
		fprintf(out, "    %s %s;\n", walker.declared_type[i] == TYPE_DOUBLE ? "double" : "long long",
				walker.declared[i]);
	if (walker.declared_count) fputc('\n', out);

	emit_native_block(body, &walker);
	fputs("    return 0;\n}\n", out);

	for (size_t i = 0; i < walker.declared_count; ++i) free(walker.declared[i]);
	free(walker.declared);
	free(walker.declared_type);
	Py_XDECREF(body);
}

static char *read_all(const char *path) {
	FILE *file = fopen(path, "rb"); if (!file) return NULL;
	if (fseek(file, 0, SEEK_END) != 0) { fclose(file); return NULL; }
	long size = ftell(file); rewind(file); if (size < 0) { fclose(file); return NULL; }
	char *text = malloc((size_t)size + 1); if (!text) { fclose(file); return NULL; }
	size_t read = fread(text, 1, (size_t)size, file); fclose(file); text[read] = '\0'; return text;
}

int main(int argc, char **argv) {
	if ((argc != 2 && argc != 3) || (strcmp(argv[1], "--check") == 0 && argc != 3)) {
		fprintf(stderr, "usage: %s [--check] input.py [output.c]\n", argv[0]); return 2;
	}
	int check_only = strcmp(argv[1], "--check") == 0;
	const char *input = check_only ? argv[2] : argv[1];
	const char *output = check_only ? NULL : argv[2];
	char *source = read_all(input);
	if (!source) { fprintf(stderr, "cannot read %s: %s\n", input, strerror(errno)); return 1; }

	Py_Initialize();
	PyObject *ast = PyImport_ImportModule("ast");
	PyObject *parse = ast ? PyObject_GetAttrString(ast, "parse") : NULL;
	PyObject *text = PyUnicode_FromString(source);
	PyObject *module = parse && text ? PyObject_CallFunction(parse, "Os", text, "exec") : NULL;
	if (!module) { PyErr_Print(); Py_XDECREF(text); Py_XDECREF(parse); Py_XDECREF(ast); Py_Finalize(); free(source); return 1; }

	Walker checker = {NULL, 0, 1, NULL, NULL, NULL, 0};
	PyObject *body = field(module, "body");
	if (body) for (Py_ssize_t i = 0; i < PyList_Size(body); ++i) supported_stmt(PyList_GetItem(body, i), &checker);
	if (check_only) {
		printf("%s: %s\n", checker.supported ? "supported" : "fallback", checker.supported ? "native C subset" : checker.reason);
	} else {
		FILE *out = fopen(output, "w");
		if (!out) { fprintf(stderr, "cannot write %s: %s\n", output, strerror(errno)); return 1; }
		if (checker.supported) generate_native(module, out);
		else { fprintf(stderr, "warning: %s; generated fallback runner\n", checker.reason); emit_python_fallback(out, source); }
		fclose(out);
	}
	Py_XDECREF(body); Py_DECREF(module); Py_DECREF(text); Py_DECREF(parse); Py_DECREF(ast);
	Py_Finalize(); free(source); return 0;
}